# Case acceptance

- All eight quote cases are traced from original inputs through requirements to explicit acceptance results.
- The prototype reproduces exact expected monetary totals using decimal half-up line and shipping-tax rounding.
- Missing data blocks readiness; policy exceptions require review; even a clean quote still requires human approval.
- Each exception has a proposed accountable role, handoff payload, and return path.
- The pilot case reports hypotheses and measurement plans, never fabricated savings or a completed deployment.

No reference artifact counts as completed work without review.
