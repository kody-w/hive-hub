# Game Engineering

Role: game-engineer

Maintain the deterministic engine and keyboard-first offline browser build.

Case inputs and logical deliverables belong to the same-world casework workspace.
Read only the inputs for assigned work; hand off verified artifact references.
Do not claim another team's task or authorize external effects.
