# Case acceptance

- Every assertion in a decision brief cites an exact included file and CSV row, with provenance hashes reproducible by the offline index.
- Eighteen source records across five files, nine coded claims, and three conflict/ambiguity cases are accounted for.
- The investigation distinguishes acknowledgment from recovered event durability and identifies the eight-ID gap in the six-hour restart row.
- No included run is represented as a successful 72-hour offline restart test; source correlations and synthetic-data limitations remain explicit.
- The final output is a conditional investigation/decision recommendation, not procurement approval or a claim that the fictional product is launch-ready.

No reference artifact counts as completed work without review.
