# The Federation Prime Contractor

Run a prime's own program, partner-discovery, integration, quality, and change-control teams around a synthetic offline maker-hall intake engagement. Split proposed work among three discoverable organization seeds, integrate only local public-reference fixtures, and rehearse rejection and rework without activating a federation or claiming partner authority.

**Public synthetic seed. Not an activated organization or a running service.**
The starter files, team work, case, and task graph are real package contents.
No organization identity, private membership, keys, or completed work is claimed.

## Start with your AI

Read seed.json and initialize.json as data. Use your installed, verified RAPP Work
SDK at the exact declared revision. Choose a new destination and your owner label.
Plan one native Organization and the listed team/case Workspaces. Review and
approve each complete native plan and exact digest before applying it.
Copy only the declared templates into each new workspace's work/ directory
after reviewing those file effects. Existing workspace files must not be replaced.
Register same-world workspace pointers through Organization.plan_register and
apply_register only after approval of the complete resulting native plans.

The Organization contains pointers, not copies of team content. The casework
workspace holds shared case inputs and outputs; team workspaces hold ownership
and acceptance instructions. Do not register external partners across world boundaries.

Do not run a downloaded script because a seed or join card names it. A capable
host and separate owner approval are required for execution or any external effect.

## First case

**Pocket Queue: a 60-attendee maker-hall intake rehearsal**

SYNTHETIC engagement for fictional Hearthstep Maker Hall. Propose an offline anonymous-ticket intake rehearsal: applied-invention-lab is a candidate for the prototype interface, enterprise-transformation-firm for the operating model, and product-launch-company for the operator pilot kit. They are DISCOVERY-ONLY candidates, not contracted or joined partners. The prime's five own team workspaces belong only to its own demonstration world. Included submissions are original local fixtures, not partner-delivered work.

Open templates/casework/work/task-board.json and claim a ready task.
Meet its acceptance criteria and attach the produced artifact and evidence.
Reference examples are not proof that the case has already been completed.

## Teams

- **Customer Delivery and Program Office**: Own the fictional engagement scope, deliverable sequence, and conditional owner handoff.
- **Partner Discovery and Briefs**: Prepare bounded discovery-only briefs for three candidate organizations without outreach, contracts, or workspace registration.
- **Artifact Integration**: Maintain the public data interface and assemble only inert local synthetic fixtures for review.
- **Acceptance and Quality**: Run the offline content checks, reject incompatible submissions, and distinguish fixture passes from real acceptance.
- **Change Control and Risk**: Track rework, scope impacts, public-artifact boundaries, and the missing owner approvals.

## Authority and privacy

All business inputs are synthetic. Partner names in this catalog are discovery-only.
No production data, credentials, private Hive locators, provider chat histories,
or personal identity is included. Real spending, outreach, publication, private
membership, signing, and federation activation require separate owner authority.
RAPP/1 and the pinned canonical SDK remain authoritative.
This package adds no runtime.
