# Artifact Integration

Role: integration-lead

Maintain the public data interface and assemble only inert local synthetic fixtures for review.

Case inputs and logical deliverables belong to the same-world casework workspace.
Read only the inputs for assigned work; hand off verified artifact references.
Do not claim another team's task or authorize external effects.
